require('dotenv').config();
const { Client, GatewayIntentBits, SlashCommandBuilder, REST, Routes } = require('discord.js');
const { joinVoiceChannel, createAudioPlayer, createAudioResource, AudioPlayerStatus } = require('@discordjs/voice');
const play = require('play-dl');

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildVoiceStates]
});

client.once('ready', async () => {
  console.log(`Logged in as ${client.user.tag}`);

  const commands = [
    new SlashCommandBuilder()
      .setName('play')
      .setDescription('Play Spotify link or song name')
      .addStringOption(option =>
        option.setName('query')
          .setDescription('Spotify link or song name')
          .setRequired(true)),
    new SlashCommandBuilder().setName('stop').setDescription('Stop music')
  ].map(cmd => cmd.toJSON());

  const rest = new REST({ version: '10' }).setToken(process.env.TOKEN);
  await rest.put(
    Routes.applicationCommands(client.user.id),
    { body: commands }
  );

  console.log("Slash commands registered!");
});

client.on('interactionCreate', async interaction => {
  if (!interaction.isChatInputCommand()) return;

  if (interaction.commandName === 'play') {
    if (!interaction.member.voice.channel)
      return interaction.reply({ content: "Join voice channel first!", ephemeral: true });

    await interaction.deferReply();

    let query = interaction.options.getString('query');

    // If Spotify link, get song info
    if (play.sp_validate(query) === 'track') {
      const spotifyData = await play.spotify(query);
      query = `${spotifyData.name} ${spotifyData.artists[0].name}`;
    }

    const ytResult = await play.search(query, { limit: 1 });
    if (!ytResult.length)
      return interaction.editReply("No results found!");

    const stream = await play.stream(ytResult[0].url);

    const connection = joinVoiceChannel({
      channelId: interaction.member.voice.channel.id,
      guildId: interaction.guild.id,
      adapterCreator: interaction.guild.voiceAdapterCreator
    });

    const player = createAudioPlayer();
    const resource = createAudioResource(stream.stream, { inputType: stream.type });

    player.play(resource);
    connection.subscribe(player);

    player.on(AudioPlayerStatus.Idle, () => {
      connection.destroy();
    });

    interaction.editReply(`Now playing: ${ytResult[0].title}`);
  }

  if (interaction.commandName === 'stop') {
    interaction.reply("Stopped.");
    const connection = joinVoiceChannel({
      channelId: interaction.member.voice.channel.id,
      guildId: interaction.guild.id,
      adapterCreator: interaction.guild.voiceAdapterCreator
    });
    connection.destroy();
  }
});

client.login(process.env.TOKEN);
